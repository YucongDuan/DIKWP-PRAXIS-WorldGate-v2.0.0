# SPDX-License-Identifier: Apache-2.0
from .cli import main
raise SystemExit(main())
